<?php
session_start();

if (!isset($_SESSION['rm'])) {
    header("Location: ../index.html");
    exit();
}

include "conecta.php";

$rm = $_SESSION['rm'];
$sql = "SELECT * FROM alunos WHERE rm='$rm'";
$resultado = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel do Aluno</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="conatiner">
        <h1>Painel do Aluno</h1>
        <h2>Bem-vindo, <?php echo $dados['nome']; ?>!</h2>
        <p><a href="dados.php"><button>Meus Dados</button></a></p>
        <p><a href="editar.php"><button>Editar Perfil</button></a></p>
        <p><a href="sair.php"><button>sair</button></a></p>
    </div>
</body>
</html>