<?php
session_start();

if (!isset($_SESSION['rm'])) {
    header("Location: ../index.html");
    exit();
}

include "conecta.php";

$rm = $_SESSION['rm'];
$nome = $_POST['nome'];
$senha = $_POST['senha'];
$curso = $_POST['curso'];
$ano = $_POST['ano'];
$sql = "UPDATE alunos SET nome='$nome', senha='$senha', curso='$curso', ano='$ano' WHERE rm='$rm'";

if (mysqli_query($conexao, $sql)) {

    echo "Dados atualizados com sucesso!<br><br>";
    echo "<a href='painel.php'>Voltar</a>";

} else {

    echo "Erro ao atualizar: " . mysqli_error($conexao);

}

mysqli_close($conexao);
?>