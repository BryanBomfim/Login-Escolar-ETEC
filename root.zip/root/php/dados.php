<?php
session_start();

if (!isset($_SESSION['rm'])) {
    header("Location: ../index.html");
    exit();
}

include "conecta.php";

$rm = $_SESSION['rm'];
$sql = "SELECT * FROM alunos WHERE rm='$rm'";
$resultado = mysqli_query($conexao, $sql);

$dados = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meus Dados</title>
    <link rel="stylesheet" href="../css/style.css">
<body>
    </head>
    <body>
        <div class="container">
            <h2>Meus Dados</h2>
            <p><b>Nome:</b> <?php echo $dados['nome']; ?></p>
            <p><b>RM:</b> <?php echo $dados['rm']; ?></p>
            <p><b>Curso:</b> <?php echo $dados['curso']; ?></p>
            <p><b>Ano:</b> <?php echo $dados['ano']; ?></p>
            <br>
            <p><a href="painel.php"><button>Voltar</button></a></p>
        </div>
    </body>
</html>