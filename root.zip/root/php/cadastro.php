<?php
include "conecta.php";

// recebe os dados do formulário
$nome = $_POST['nome'];
$rm = $_POST['rm'];
$senha = $_POST['senha'];
$curso = $_POST['curso'];
$ano = $_POST['ano'];

$sql_verifica = "SELECT * FROM alunos WHERE rm='$rm'";
$resultado = mysqli_query($conexao, $sql_verifica);

if (mysqli_num_rows($resultado) > 0) {

    echo "Este RM ja esta cadastrado.<br><br>";
    echo "<a href='../cadastro.html'>Voltar</a>";

} else {
    $sql = "INSERT INTO alunos (nome, rm, senha, curso, ano)
    VALUES ('$nome','$rm','$senha','$curso','$ano')";
    if (mysqli_query($conexao, $sql)) {
        echo "Cadastro realizado com sucesso!";
        echo "<p><a href='../index.html'>Voltar</a></p>";
    } else {
        echo "Erro ao cadastrar: " . mysqli_error($conexao);
        echo "<p><a href='../index.html'>Voltar</a></p>";

    }
}
?>