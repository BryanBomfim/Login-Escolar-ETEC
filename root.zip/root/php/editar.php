<?php

session_start();

if (!isset($_SESSION['rm'])) {
    header("Location: ../index.html");
    exit();
}

include "conecta.php";

$rm = $_SESSION['rm'];
$sql = "SELECT * FROM alunos WHERE rm='$rm'";
$resultado = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="../css/style.css">

</head>
<body>
    <div class="conatiner">
        <h2>Editar Perfil</h2>
        <form action="atualizar.php" method="POST">
            <p>
                Nome:<br>
                <input type="text" name="nome" value="<?php echo $dados['nome']; ?>" required>
            </p>
            <p>
                Senha:<br>
                <input type="password" name="senha" value="<?php echo $dados['senha']; ?>" required>
            </p>
            <label>Curso:</label><br>
            <select name="curso" required>
                <option value="">Selecione</option>
                <option value="Informatica para Internet">Informática para Internet</option>
                <option value="ADM">Administração</option>
                <option value="Meio Ambiente">Meio Ambiente</option>
            </select><br><br>

            <label>Ano:</label><br>
            <select name="ano" required>
                <option value="">Selecione</option>
                <option value="1">1º</option>
                <option value="2">2º </option>
                <option value="3">3º </option>
            </select><br><br>
            <p><button type="submit">Atualizar dados</button></p>
        </form>
        <p><a href="painel.php"><button>Voltar</button></a></p>
    </div>
</body>
</html>