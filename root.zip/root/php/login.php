<?php
session_start();
include "conecta.php";

if (isset($_POST['rm']) && isset($_POST['senha'])) {
    $rm = $_POST['rm'];
    $senha = $_POST['senha'];
    $sql = "SELECT * FROM alunos WHERE rm='$rm' AND senha='$senha'";
    $resultado = mysqli_query($conexao, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        $_SESSION['rm'] = $rm;
        header("Location: painel.php");
        exit();
    } else {
        echo "RM ou senha incorretos";
        echo "<p><a href='../index.html'>Voltar</a><p>";
    }
}
?>